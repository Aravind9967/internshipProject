package com.healthcare.healthcare_booking_system.Exceptions;

public class SlotUnavailableException extends RuntimeException {

    public SlotUnavailableException(String message) {
        super(message);
    }

    public static SlotUnavailableException forSlot(Long slotId) {
        return new SlotUnavailableException(
                "Slot " + slotId + " is no longer available — please choose another slot.");
    }
}
