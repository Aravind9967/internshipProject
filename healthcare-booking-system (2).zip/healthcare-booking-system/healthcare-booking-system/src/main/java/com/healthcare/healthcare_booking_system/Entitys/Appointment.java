package com.healthcare.healthcare_booking_system.Entitys;

import java.time.LocalDateTime;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Appointment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    private String patientName;

    @Pattern(regexp = "^[0-9]{10}$", message = "Patient phone number must contain exactly 10 digits")
    @Column(nullable = false, length = 10)
    private String patientPhone;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ProviderType providerType;

    @Column(nullable = false)
    private Long providerId;

    @Column(nullable = false)
    private Long slotId;

    @Column(nullable = false)
    private Double priceCharged;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private AppointmentStatus status;

    @Column(nullable = false)
    private LocalDateTime bookedAt;

    private Integer estimatedWaitMinutes;

    private String confirmationCode;
}