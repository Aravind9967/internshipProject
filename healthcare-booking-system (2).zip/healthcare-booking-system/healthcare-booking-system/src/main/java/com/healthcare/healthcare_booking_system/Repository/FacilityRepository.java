package com.healthcare.healthcare_booking_system.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.healthcare.healthcare_booking_system.Entitys.Facility;
import com.healthcare.healthcare_booking_system.Entitys.ProviderType;

public interface FacilityRepository extends JpaRepository<Facility, Long> {
	List<Facility> findByType(ProviderType type);

}
