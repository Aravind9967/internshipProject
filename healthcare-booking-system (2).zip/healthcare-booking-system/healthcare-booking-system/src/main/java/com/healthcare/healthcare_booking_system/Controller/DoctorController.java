package com.healthcare.healthcare_booking_system.Controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.healthcare.healthcare_booking_system.DTOs.DoctorRequest;
import com.healthcare.healthcare_booking_system.DTOs.DoctorSearchResult;
import com.healthcare.healthcare_booking_system.Entitys.Doctor;
import com.healthcare.healthcare_booking_system.Services.DoctorSearchService;
import com.healthcare.healthcare_booking_system.Services.DoctorService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/doctors")
@RequiredArgsConstructor
public class DoctorController {

    private final DoctorSearchService doctorSearchService;
    private final DoctorService doctorService;

    @GetMapping("/search")
    public ResponseEntity<List<DoctorSearchResult>> search(
            @RequestParam(required = false) String specialization,
            @RequestParam(required = false) Double lat,
            @RequestParam(required = false) Double lng,
            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {

        LocalDate searchDate = (date != null) ? date : LocalDate.now();
        List<DoctorSearchResult> results = doctorSearchService.search(specialization, lat, lng, searchDate);
        return ResponseEntity.ok(results);
    }
    
    @PostMapping
    public ResponseEntity<Doctor> addDoctor(@Valid @RequestBody DoctorRequest request) {
        Doctor saved = doctorService.addDoctor(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteDoctor(@PathVariable Long id) {
        doctorService.deleteDoctor(id);
        return ResponseEntity.noContent().build();
    }
}