package com.healthcare.healthcare_booking_system.Services;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;

import org.springframework.stereotype.Service;

import com.healthcare.healthcare_booking_system.DTOs.LabSearchResult;
import com.healthcare.healthcare_booking_system.Entitys.LabTest;
import com.healthcare.healthcare_booking_system.Entitys.ProviderType;
import com.healthcare.healthcare_booking_system.Entitys.SlotStatus;
import com.healthcare.healthcare_booking_system.Repository.LabTestRepository;
import com.healthcare.healthcare_booking_system.Repository.SlotRepository;
import com.healthcare.healthcare_booking_system.Util.DistanceUtil;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class LabSearchService {

    private final LabTestRepository labTestRepository;
    private final SlotRepository slotRepository;

    public List<LabSearchResult> search(String testName, Double lat, Double lng, LocalDate date) {
        List<LabTest> tests = findLabTests(testName);

        return tests.stream()
                .map(test -> createSearchResult(test, lat, lng, date))
                .sorted(byNearestDistance())
                .toList();
    }

    private List<LabTest> findLabTests(String testName) {
        if (testName == null || testName.isBlank()) {
            return labTestRepository.findAll();
        }
        return labTestRepository.findByTestNameIgnoreCaseContaining(testName);
    }

    private LabSearchResult createSearchResult(LabTest test, Double lat, Double lng, LocalDate date) {
        Double distanceKm = null;
        Integer travelMinutes = null;

        if (lat != null && lng != null) {
            distanceKm = DistanceUtil.distanceKm(
                    lat, lng,
                    test.getFacility().getLatitude(),
                    test.getFacility().getLongitude()
            );
            travelMinutes = DistanceUtil.estimatedTravelMinutes(distanceKm);
        }

        int availableSlotCount = countAvailableSlots(test.getId(), date);

        return LabSearchResult.builder()
                .labTestId(test.getId())
                .testName(test.getTestName())
                .price(test.getPrice())
                .reportTimeHours(test.getReportTimeHours())
                .homeSampleCollection(test.isHomeSampleCollection())
                .facilityName(test.getFacility().getName())
                .distanceKm(distanceKm)
                .estimatedTravelMinutes(travelMinutes)
                .availableSlotCount(availableSlotCount)
                .build();
    }

    private int countAvailableSlots(Long labTestId, LocalDate date) {
        return (int) slotRepository.countByProviderTypeAndProviderIdAndDateAndStatus(
                ProviderType.LAB,
                labTestId,
                date,
                SlotStatus.AVAILABLE
        );
    }

    private Comparator<LabSearchResult> byNearestDistance() {
        return Comparator.comparing(
                LabSearchResult::getDistanceKm,
                Comparator.nullsLast(Double::compareTo)
        );
    }
}