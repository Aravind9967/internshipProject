package com.healthcare.healthcare_booking_system.Services;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.healthcare.healthcare_booking_system.DTOs.BookingRequest;
import com.healthcare.healthcare_booking_system.DTOs.BookingResponse;
import com.healthcare.healthcare_booking_system.Entitys.Appointment;
import com.healthcare.healthcare_booking_system.Entitys.AppointmentStatus;
import com.healthcare.healthcare_booking_system.Entitys.ProviderType;
import com.healthcare.healthcare_booking_system.Entitys.Slot;
import com.healthcare.healthcare_booking_system.Entitys.SlotStatus;
import com.healthcare.healthcare_booking_system.Exceptions.InvalidBookingException;
import com.healthcare.healthcare_booking_system.Exceptions.ResourceNotFoundException;
import com.healthcare.healthcare_booking_system.Exceptions.SlotUnavailableException;
import com.healthcare.healthcare_booking_system.Repository.AppointmentRepository;
import com.healthcare.healthcare_booking_system.Repository.DoctorRepository;
import com.healthcare.healthcare_booking_system.Repository.LabTestRepository;
import com.healthcare.healthcare_booking_system.Repository.SlotRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class BookingService {

    private static final int MINUTES_PER_QUEUE_SLOT = 15;

    private final SlotRepository slotRepository;
    private final AppointmentRepository appointmentRepository;
    private final DoctorRepository doctorRepository;
    private final LabTestRepository labTestRepository;

    @Transactional
    public BookingResponse book(BookingRequest request) {
        Slot slot = findSlot(request.getSlotId());
        validateSlot(slot, request);

        double price = getPrice(request.getProviderType(), request.getProviderId());
        markSlotAsBooked(slot);

        int estimatedWait = calculateEstimatedWait(request.getProviderType(), request.getProviderId(), slot);
        String confirmationCode = generateConfirmationCode();

        Appointment appointment = createAppointment(request, slot, price, estimatedWait, confirmationCode);
        appointment = appointmentRepository.save(appointment);

        return buildBookingResponse(appointment, slot, confirmationCode, price, estimatedWait);
    }

    @Transactional(readOnly = true)
    public Appointment getStatus(Long appointmentId) {
        return appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> ResourceNotFoundException.of("Appointment", appointmentId));
    }

    @Transactional
    public Appointment cancel(Long appointmentId) {
        Appointment appointment = getStatus(appointmentId);

        if (appointment.getStatus() == AppointmentStatus.CANCELLED) {
            throw new InvalidBookingException("Appointment is already cancelled.");
        }

        appointment.setStatus(AppointmentStatus.CANCELLED);

        Slot slot = findSlot(appointment.getSlotId());
        slot.setStatus(SlotStatus.AVAILABLE);
        slotRepository.save(slot);

        return appointmentRepository.save(appointment);
    }

    private Slot findSlot(Long slotId) {
        return slotRepository.findById(slotId)
                .orElseThrow(() -> ResourceNotFoundException.of("Slot", slotId));
    }

    private void validateSlot(Slot slot, BookingRequest request) {
        if (slot.getStatus() != SlotStatus.AVAILABLE) {
            throw SlotUnavailableException.forSlot(slot.getId());
        }

        if (!slot.getProviderType().equals(request.getProviderType())
                || !slot.getProviderId().equals(request.getProviderId())) {
            throw new InvalidBookingException("This slot does not belong to the selected provider.");
        }
    }

    private void markSlotAsBooked(Slot slot) {
        slot.setStatus(SlotStatus.BOOKED);
        slotRepository.save(slot);
    }

    private int calculateEstimatedWait(ProviderType type, Long providerId, Slot slot) {
        LocalDateTime start = slot.getDate().atStartOfDay();
        LocalDateTime end = slot.getDate().atTime(23, 59, 59);

        long confirmedCount = appointmentRepository
                .countByProviderTypeAndProviderIdAndStatusAndBookedAtBetween(
                    type,
                    providerId,
                    AppointmentStatus.CONFIRMED,
                    start,
                    end
                );

        return (int) confirmedCount * MINUTES_PER_QUEUE_SLOT;
    }

    private String generateConfirmationCode() {
        return "AYU-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    }

    private Appointment createAppointment(BookingRequest request, Slot slot,
                                        double price, int estimatedWait,
                                        String confirmationCode) {
        return Appointment.builder()
                .patientName(request.getPatientName())
                .patientPhone(request.getPatientPhone())
                .providerType(request.getProviderType())
                .providerId(request.getProviderId())
                .slotId(slot.getId())
                .priceCharged(price)
                .status(AppointmentStatus.CONFIRMED)
                .bookedAt(LocalDateTime.now())
                .estimatedWaitMinutes(estimatedWait)
                .confirmationCode(confirmationCode)
                .build();
    }

    private BookingResponse buildBookingResponse(Appointment appointment, Slot slot,
                                               String confirmationCode, double price,
                                               int estimatedWait) {
        String providerName = getProviderName(appointment.getProviderType(), appointment.getProviderId());

        return BookingResponse.builder()
                .appointmentId(appointment.getId())
                .confirmationCode(confirmationCode)
                .status(appointment.getStatus())
                .providerType(appointment.getProviderType())
                .providerName(providerName)
                .priceCharged(price)
                .estimatedWaitMinutes(estimatedWait)
                .bookedAt(appointment.getBookedAt())
                .message("Booking confirmed for " + slot.getStartTime() + " on " + slot.getDate())
                .build();
    }

    private String getProviderName(ProviderType type, Long providerId) {
        return switch (type) {
            case DOCTOR -> doctorRepository.findById(providerId)
                    .map(doctor -> formatDoctorName(doctor.getName()))
                    .orElseThrow(() -> ResourceNotFoundException.of("Doctor", providerId));

            case LAB -> labTestRepository.findById(providerId)
                    .map(lab -> lab.getTestName())
                    .orElseThrow(() -> ResourceNotFoundException.of("LabTest", providerId));

            default -> throw new InvalidBookingException("Unsupported provider type: " + type);
        };
    }

    private String formatDoctorName(String name) {
        if (name == null || name.isBlank()) {
            return "Unknown Doctor";
        }
        String cleanName = name.replaceFirst("(?i)^Dr\\.?\\s*", "").trim();
        return "Dr. " + cleanName;
    }

 // Add these methods to BookingService.java

    @Transactional(readOnly = true)
    public List<Appointment> getPatientAppointments(String patientPhone) {
        return appointmentRepository.findByPatientPhone(patientPhone);
    }

    @Transactional(readOnly = true)
    public List<Appointment> getAllAppointments() {
        return appointmentRepository.findAll();
    }

    @Transactional
    public void deleteAppointment(Long appointmentId) {
        Appointment appointment = getStatus(appointmentId);
        
        // If appointment is not cancelled, release the slot
        if (appointment.getStatus() != AppointmentStatus.CANCELLED) {
            Slot slot = findSlot(appointment.getSlotId());
            slot.setStatus(SlotStatus.AVAILABLE);
            slotRepository.save(slot);
        }
        
        appointmentRepository.delete(appointment);
    }
    
    private double getPrice(ProviderType type, Long providerId) {
        return switch (type) {
            case DOCTOR -> doctorRepository.findById(providerId)
                    .orElseThrow(() -> ResourceNotFoundException.of("Doctor", providerId))
                    .getConsultationFee();

            case LAB -> labTestRepository.findById(providerId)
                    .orElseThrow(() -> ResourceNotFoundException.of("LabTest", providerId))
                    .getPrice();

            default -> throw new InvalidBookingException("Unsupported provider type: " + type);
        };
    }
}