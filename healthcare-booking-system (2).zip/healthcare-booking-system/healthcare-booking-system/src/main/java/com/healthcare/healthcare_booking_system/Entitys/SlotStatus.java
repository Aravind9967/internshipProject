package com.healthcare.healthcare_booking_system.Entitys;

public enum SlotStatus {
	AVAILABLE,
	BOOKED,
	BLOCKED
	
}
