package com.healthcare.healthcare_booking_system.Services;

import org.springframework.stereotype.Service;

import com.healthcare.healthcare_booking_system.DTOs.DoctorRequest;
import com.healthcare.healthcare_booking_system.Entitys.Doctor;
import com.healthcare.healthcare_booking_system.Entitys.Facility;
import com.healthcare.healthcare_booking_system.Exceptions.InvalidBookingException;
import com.healthcare.healthcare_booking_system.Exceptions.ResourceNotFoundException;
import com.healthcare.healthcare_booking_system.Repository.DoctorRepository;
import com.healthcare.healthcare_booking_system.Repository.FacilityRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class DoctorService {

    private final DoctorRepository doctorRepository;
    private final FacilityRepository facilityRepository;

    public Doctor addDoctor(DoctorRequest request) {
        validateDoctorRequest(request);

        Facility facility = facilityRepository.findById(request.getFacilityId())
                .orElseThrow(() -> ResourceNotFoundException.of("Facility", request.getFacilityId()));

        Doctor doctor = Doctor.builder()
                .name(formatDoctorName(request.getName()))
                .specialization(request.getSpecialization())
                .yearsOfExperience(request.getYearsOfExperience())
                .consultationFee(request.getConsultationFee())
                .rating(request.getRating() != null ? request.getRating() : 0.0)
                .verified(request.isVerified())
                .facility(facility)
                .build();

        return doctorRepository.save(doctor);
    }

    public void deleteDoctor(Long doctorId) {
        Doctor doctor = doctorRepository.findById(doctorId)
                .orElseThrow(() -> ResourceNotFoundException.of("Doctor", doctorId));

        doctorRepository.delete(doctor);
    }

    private void validateDoctorRequest(DoctorRequest request) {
        if (request.getConsultationFee() == null || request.getConsultationFee() <= 0) {
            throw new InvalidBookingException("Consultation fee must be positive");
        }

        if (request.getRating() != null && (request.getRating() < 0 || request.getRating() > 5)) {
            throw new InvalidBookingException("Rating must be between 0 and 5");
        }

        if (request.getYearsOfExperience() != null && request.getYearsOfExperience() < 0) {
            throw new InvalidBookingException("Years of experience cannot be negative");
        }
    }

    private String formatDoctorName(String name) {
        if (name == null || name.isBlank()) {
            return "Unknown Doctor";
        }
        String cleanName = name.replaceFirst("(?i)^Dr\\.?\\s*", "").trim();
        return "Dr. " + cleanName;
    }
}