package com.healthcare.healthcare_booking_system.Controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.healthcare.healthcare_booking_system.DTOs.SlotRequest;
import com.healthcare.healthcare_booking_system.Entitys.Slot;
import com.healthcare.healthcare_booking_system.Services.SlotService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/slots")
@RequiredArgsConstructor
public class SlotController {

    private final SlotService slotService;

    @PostMapping("/add")
    public ResponseEntity<Slot> addSlot(@Valid @RequestBody SlotRequest request) {
        Slot saved = slotService.addSlot(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteSlot(@PathVariable Long id) {
        slotService.deleteSlot(id);
        return ResponseEntity.noContent().build();
    }
}