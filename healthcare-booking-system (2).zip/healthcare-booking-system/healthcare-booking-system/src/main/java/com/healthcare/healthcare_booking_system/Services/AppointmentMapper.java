package com.healthcare.healthcare_booking_system.Services;

import org.springframework.stereotype.Component;

import com.healthcare.healthcare_booking_system.DTOs.AppointmentStatusResponse;
import com.healthcare.healthcare_booking_system.Entitys.Appointment;
import com.healthcare.healthcare_booking_system.Entitys.ProviderType;
import com.healthcare.healthcare_booking_system.Exceptions.ResourceNotFoundException;
import com.healthcare.healthcare_booking_system.Repository.DoctorRepository;
import com.healthcare.healthcare_booking_system.Repository.LabTestRepository;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class AppointmentMapper {

    private final DoctorRepository doctorRepository;
    private final LabTestRepository labTestRepository;

    public AppointmentStatusResponse toResponse(Appointment appointment) {
        return AppointmentStatusResponse.builder()
                .appointmentId(appointment.getId())
                .confirmationCode(appointment.getConfirmationCode())
                .status(appointment.getStatus())
                .providerType(appointment.getProviderType())
                .providerName(findProviderName(appointment.getProviderType(), appointment.getProviderId()))
                .patientName(appointment.getPatientName())
                .phone(appointment.getPatientPhone())
                .priceCharged(appointment.getPriceCharged())
                .estimatedWaitMinutes(appointment.getEstimatedWaitMinutes())
                .bookedAt(appointment.getBookedAt())
                .build();
    }

    private String findProviderName(ProviderType type, Long providerId) {
        return switch (type) {
            case DOCTOR -> doctorRepository.findById(providerId)
                    .map(doctor -> formatDoctorName(doctor.getName()))
                    .orElseThrow(() -> ResourceNotFoundException.of("Doctor", providerId));

            case LAB -> labTestRepository.findById(providerId)
                    .map(lab -> lab.getTestName())
                    .orElseThrow(() -> ResourceNotFoundException.of("LabTest", providerId));

            default -> "Unknown Provider";
        };
    }

    private String formatDoctorName(String name) {
        if (name == null || name.isBlank()) {
            return "Unknown Doctor";
        }
        String cleanName = name.replaceFirst("(?i)^Dr\\.?\\s*", "").trim();
        return "Dr. " + cleanName;
    }
}