package com.healthcare.healthcare_booking_system.Services;

import java.util.Comparator;
import java.util.List;

import org.springframework.stereotype.Service;

import com.healthcare.healthcare_booking_system.DTOs.FacilitySearchResult;
import com.healthcare.healthcare_booking_system.Entitys.Facility;
import com.healthcare.healthcare_booking_system.Repository.DoctorRepository;
import com.healthcare.healthcare_booking_system.Repository.FacilityRepository;
import com.healthcare.healthcare_booking_system.Util.DistanceUtil;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class FacilitySearchService {

    private final FacilityRepository facilityRepository;
    private final DoctorRepository doctorRepository;

    public List<FacilitySearchResult> searchNearby(Double lat, Double lng, Double radiusKm, String subtype) {
        List<Facility> facilities = facilityRepository.findAll();

        return facilities.stream()
                .filter(facility -> matchesSubtype(facility, subtype))
                .map(facility -> createResult(facility, lat, lng))
                .filter(result -> isWithinRadius(result, radiusKm))
                .sorted(byNearestDistance())
                .toList();
    }

    private boolean matchesSubtype(Facility facility, String subtype) {
        if (subtype == null || subtype.isBlank()) {
            return true;
        }
        return subtype.equalsIgnoreCase(facility.getSubType());
    }

    private FacilitySearchResult createResult(Facility facility, Double lat, Double lng) {
        Double distanceKm = null;
        Integer travelMinutes = null;

        if (lat != null && lng != null) {
            distanceKm = DistanceUtil.distanceKm(
                    lat, lng,
                    facility.getLatitude(),
                    facility.getLongitude()
            );
            travelMinutes = DistanceUtil.estimatedTravelMinutes(distanceKm);
        }

        int totalDoctors = (int) doctorRepository.countByFacilityId(facility.getId());

        return FacilitySearchResult.builder()
                .facilityId(facility.getId())
                .name(facility.getName())
                .subtype(facility.getSubType())
                .address(facility.getAddress())
                .rating(facility.getRating())
                .verified(facility.isVerified())
                .distanceKm(distanceKm)
                .estimatedTravelMinutes(travelMinutes)
                .doctorsAvailableToday(totalDoctors)
                .build();
    }

    private boolean isWithinRadius(FacilitySearchResult result, Double radiusKm) {
        if (radiusKm == null || result.getDistanceKm() == null) {
            return true;
        }
        return result.getDistanceKm() <= radiusKm;
    }

    private Comparator<FacilitySearchResult> byNearestDistance() {
        return Comparator.comparing(
                FacilitySearchResult::getDistanceKm,
                Comparator.nullsLast(Double::compareTo)
        );
    }
}