package com.healthcare.healthcare_booking_system.Controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.healthcare.healthcare_booking_system.DTOs.AppointmentStatusResponse;
import com.healthcare.healthcare_booking_system.DTOs.BookingRequest;
import com.healthcare.healthcare_booking_system.DTOs.BookingResponse;
import com.healthcare.healthcare_booking_system.Entitys.Appointment;
import com.healthcare.healthcare_booking_system.Services.AppointmentMapper;
import com.healthcare.healthcare_booking_system.Services.BookingService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/appointments")
public class AppointmentController {

    private final BookingService bookingService;
    private final AppointmentMapper appointmentMapper;

    @PostMapping
    public ResponseEntity<BookingResponse> book(@Valid @RequestBody BookingRequest request) {
        BookingResponse response = bookingService.book(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @GetMapping("/{id}/status")
    public ResponseEntity<AppointmentStatusResponse> status(@PathVariable Long id) {
        Appointment appointment = bookingService.getStatus(id);
        AppointmentStatusResponse response = appointmentMapper.toResponse(appointment);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/{id}/cancel")
    public ResponseEntity<AppointmentStatusResponse> cancel(@PathVariable Long id) {
        Appointment appointment = bookingService.cancel(id);
        AppointmentStatusResponse response = appointmentMapper.toResponse(appointment);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/patient/{phone}")
    public ResponseEntity<List<AppointmentStatusResponse>> getPatientAppointments(
            @PathVariable String phone) {
        List<Appointment> appointments = bookingService.getPatientAppointments(phone);
        List<AppointmentStatusResponse> responses = appointments.stream()
                .map(appointmentMapper::toResponse)
                .toList();
        return ResponseEntity.ok(responses);
    }

    @GetMapping
    public ResponseEntity<List<AppointmentStatusResponse>> getAllAppointments() {
        List<Appointment> appointments = bookingService.getAllAppointments();
        List<AppointmentStatusResponse> responses = appointments.stream()
                .map(appointmentMapper::toResponse)
                .toList();
        return ResponseEntity.ok(responses);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteAppointment(@PathVariable Long id) {
        bookingService.deleteAppointment(id);
        return ResponseEntity.noContent().build();
    }
}