package com.healthcare.healthcare_booking_system.DTOs;

import java.time.LocalDate;
import java.time.LocalTime;

import com.healthcare.healthcare_booking_system.Entitys.ProviderType;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SlotRequest {

    @NotNull(message = "Provider type is required")
    private ProviderType providerType;

    @NotNull(message = "Provider id is required")
    private Long providerId;

    @NotNull(message = "Date is required")
    private LocalDate date;

    @NotNull(message = "Start time is required")
    private LocalTime startTime;

    @NotNull(message = "End time is required")
    private LocalTime endTime;
}