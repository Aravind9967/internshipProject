package com.healthcare.healthcare_booking_system.Controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.healthcare.healthcare_booking_system.DTOs.FacilityRequest;
import com.healthcare.healthcare_booking_system.DTOs.FacilitySearchResult;
import com.healthcare.healthcare_booking_system.Entitys.Facility;
import com.healthcare.healthcare_booking_system.Services.FacilitySearchService;
import com.healthcare.healthcare_booking_system.Services.FacilityService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/facilities")
@RequiredArgsConstructor
public class FacilityController {

    private final FacilityService facilityService;
    private final FacilitySearchService facilitySearchService;

    @PostMapping
    public ResponseEntity<Facility> createFacility(@RequestBody FacilityRequest request) {
        Facility facility = facilityService.createFacility(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(facility);
    }

    @GetMapping
    public ResponseEntity<List<Facility>> getAllFacilities() {
        List<Facility> facilities = facilityService.getAllFacilities();
        return ResponseEntity.ok(facilities);
    }

    @GetMapping("/search/nearby")
    public ResponseEntity<List<FacilitySearchResult>> searchNearby(
            @RequestParam(required = false) Double lat,
            @RequestParam(required = false) Double lng,
            @RequestParam(required = false) Double radiusKm,
            @RequestParam(required = false) String subtype) {
        
        List<FacilitySearchResult> results = facilitySearchService.searchNearby(lat, lng, radiusKm, subtype);
        return ResponseEntity.ok(results);
    }
}