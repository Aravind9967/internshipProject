package com.healthcare.healthcare_booking_system.Util;

public final class DistanceUtil {

    private static final double EARTH_RADIUS_KM = 6371.0;

    private DistanceUtil() {}

    /**
     * Returns distance in kilometers between two lat/lng points using the
     * Haversine formula, rounded to 2 decimal places.
     */
    public static double distanceKm(double lat1, double lon1, double lat2, double lon2) {
        double dLat = Math.toRadians(lat2 - lat1);
        double dLon = Math.toRadians(lon2 - lon1);

        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
                + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
                * Math.sin(dLon / 2) * Math.sin(dLon / 2);

        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        double distance = EARTH_RADIUS_KM * c;

        return Math.round(distance * 100.0) / 100.0;
    }

    /** Rough travel time estimate assuming average urban speed of 25 km/h. */
    public static int estimatedTravelMinutes(double distanceKm) {
        double hours = distanceKm / 25.0;
        return (int) Math.ceil(hours * 60);
    }
}

