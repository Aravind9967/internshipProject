package com.healthcare.healthcare_booking_system.DTOs;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@AllArgsConstructor
@Builder
public class LabSearchResult {
	
	    private Long labTestId;
	    private String testName;
	    private Double price;
	    private Integer reportTimeHours;
	    private boolean homeSampleCollection;
	    private String facilityName;
	    private Double distanceKm;
	    private Integer estimatedTravelMinutes;
	    private int availableSlotCount;


}
