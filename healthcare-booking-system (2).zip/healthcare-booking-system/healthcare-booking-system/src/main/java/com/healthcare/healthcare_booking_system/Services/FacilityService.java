package com.healthcare.healthcare_booking_system.Services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.healthcare.healthcare_booking_system.DTOs.FacilityRequest;
import com.healthcare.healthcare_booking_system.Entitys.Facility;
import com.healthcare.healthcare_booking_system.Exceptions.ResourceNotFoundException;
import com.healthcare.healthcare_booking_system.Repository.FacilityRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class FacilityService {

    private final FacilityRepository facilityRepository;

    public Facility createFacility(FacilityRequest request) {
        Facility facility = Facility.builder()
                .name(request.getName())
                .type(request.getType())
                .subType(request.getSubType())
                .address(request.getAddress())
                .latitude(request.getLatitude())
                .longitude(request.getLongitude())
                .rating(request.getRating())
                .verified(request.isVerified())
                .build();

        return facilityRepository.save(facility);
    }

    public List<Facility> getAllFacilities() {
        return facilityRepository.findAll();
    }

    public Facility getFacility(Long facilityId) {
        return facilityRepository.findById(facilityId)
                .orElseThrow(() -> ResourceNotFoundException.of("Facility", facilityId));
    }
}