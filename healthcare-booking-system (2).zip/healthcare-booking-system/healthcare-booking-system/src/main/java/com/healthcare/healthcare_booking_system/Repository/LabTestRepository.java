package com.healthcare.healthcare_booking_system.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.healthcare.healthcare_booking_system.Entitys.LabTest;

public interface LabTestRepository extends JpaRepository<LabTest, Long> {
    List<LabTest> findByTestNameIgnoreCaseContaining(String testName);
}

