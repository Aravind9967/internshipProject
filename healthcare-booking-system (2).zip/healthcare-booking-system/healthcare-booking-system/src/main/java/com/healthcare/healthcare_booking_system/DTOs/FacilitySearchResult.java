package com.healthcare.healthcare_booking_system.DTOs;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@AllArgsConstructor
@Builder
public class FacilitySearchResult {
	    private Long facilityId;
	    private String name;
	    private String subtype;
	    private String address;
	    private Double rating;
	    private boolean verified;
	    private Double distanceKm;
	    private Integer estimatedTravelMinutes;
	    private int doctorsAvailableToday;


}
