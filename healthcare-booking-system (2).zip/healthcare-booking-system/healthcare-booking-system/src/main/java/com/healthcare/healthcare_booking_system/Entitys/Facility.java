package com.healthcare.healthcare_booking_system.Entitys;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "facility")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Facility {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(nullable = false)
	private String name;
	
	@Enumerated(EnumType.STRING)
	@Column(nullable = false)
	private ProviderType type;
	
	private String subType;
	
	@Column(nullable = false)
	private String address;
	
	 @Column(nullable = false)
     private Double latitude;

     @Column(nullable = false)
     private Double longitude;
     
     private Double rating;
     
     private boolean verified;

	
	

}
