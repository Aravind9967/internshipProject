package com.healthcare.healthcare_booking_system.Controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.healthcare.healthcare_booking_system.DTOs.LabSearchResult;
import com.healthcare.healthcare_booking_system.Services.LabSearchService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/labs")
@RequiredArgsConstructor
public class LabController {

    private final LabSearchService labSearchService;

    @GetMapping("/search")
    public ResponseEntity<List<LabSearchResult>> search(
            @RequestParam(required = false) String testName,
            @RequestParam(required = false) Double lat,
            @RequestParam(required = false) Double lng,
            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {

        LocalDate searchDate = (date != null) ? date : LocalDate.now();
        List<LabSearchResult> results = labSearchService.search(testName, lat, lng, searchDate);
        return ResponseEntity.ok(results);
    }
}