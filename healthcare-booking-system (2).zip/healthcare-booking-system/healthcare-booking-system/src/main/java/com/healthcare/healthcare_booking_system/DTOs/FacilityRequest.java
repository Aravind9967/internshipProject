package com.healthcare.healthcare_booking_system.DTOs;

import com.healthcare.healthcare_booking_system.Entitys.ProviderType;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class FacilityRequest {

    @NotBlank
    private String name;

    @NotNull
    private ProviderType type;

    private String subType;

    @NotBlank
    private String address;

    @NotNull
    private Double latitude;

    @NotNull
    private Double longitude;

    private Double rating = 0.0;

    private boolean verified = false;
}