package com.healthcare.healthcare_booking_system.Entitys;

public enum AppointmentStatus {
    PENDING_CONFIRMATION,
    CONFIRMED,
    CANCELLED,
    COMPLETED,
    NO_SHOW          // removed leading space
}