package com.healthcare.healthcare_booking_system.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.healthcare.healthcare_booking_system.Entitys.Doctor;

public interface DoctorRepository extends JpaRepository<Doctor, Long> {
	
	List<Doctor> findBySpecializationIgnoreCaseContaining(String specialization);

	int countByFacilityId(Long id);

}
