package com.healthcare.healthcare_booking_system.DTOs;

import java.time.LocalDateTime;

import com.healthcare.healthcare_booking_system.Entitys.AppointmentStatus;
import com.healthcare.healthcare_booking_system.Entitys.ProviderType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@AllArgsConstructor
@Builder
public class AppointmentStatusResponse {

    private Long appointmentId;
    private String confirmationCode;
    private AppointmentStatus status;
    private ProviderType providerType;
    private String providerName;
    private String patientName;
    private String phone;
    private Double priceCharged;
    private Integer estimatedWaitMinutes;   // fixed typo: was EstmatedWaitMinutes
    private LocalDateTime bookedAt;
}