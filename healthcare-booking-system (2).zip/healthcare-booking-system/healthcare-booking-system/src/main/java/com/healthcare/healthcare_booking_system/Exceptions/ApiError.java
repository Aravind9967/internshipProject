package com.healthcare.healthcare_booking_system.Exceptions;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@AllArgsConstructor
@Builder
public class ApiError {
	@JsonFormat(pattern = "dd-mm-yyyy'T'HH:mm:ss")
	private LocalDateTime timestamp;
	
	private int status;
	private String error;
	private String message;
	private String path;
	

}
