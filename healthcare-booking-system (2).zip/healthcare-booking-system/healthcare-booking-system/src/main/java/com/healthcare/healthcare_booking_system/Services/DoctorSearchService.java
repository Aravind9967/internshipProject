package com.healthcare.healthcare_booking_system.Services;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Comparator;
import java.util.List;

import org.springframework.stereotype.Service;

import com.healthcare.healthcare_booking_system.DTOs.DoctorSearchResult;
import com.healthcare.healthcare_booking_system.Entitys.Doctor;
import com.healthcare.healthcare_booking_system.Entitys.ProviderType;
import com.healthcare.healthcare_booking_system.Entitys.Slot;
import com.healthcare.healthcare_booking_system.Entitys.SlotStatus;
import com.healthcare.healthcare_booking_system.Repository.DoctorRepository;
import com.healthcare.healthcare_booking_system.Repository.SlotRepository;
import com.healthcare.healthcare_booking_system.Util.DistanceUtil;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class DoctorSearchService {

    private final DoctorRepository doctorRepository;
    private final SlotRepository slotRepository;

    public List<DoctorSearchResult> search(String specialization, Double lat, Double lng, LocalDate date) {
        List<Doctor> doctors = findDoctors(specialization);

        return doctors.stream()
                .map(doctor -> createSearchResult(doctor, lat, lng, date))
                .sorted(byNearestDistance())
                .toList();
    }

    private List<Doctor> findDoctors(String specialization) {
        if (specialization == null || specialization.isBlank()) {
            return doctorRepository.findAll();
        }
        return doctorRepository.findBySpecializationIgnoreCaseContaining(specialization);
    }

    private DoctorSearchResult createSearchResult(Doctor doctor, Double lat, Double lng, LocalDate date) {
        Double distanceKm = null;
        Integer travelMinutes = null;

        if (lat != null && lng != null) {
            distanceKm = DistanceUtil.distanceKm(
                    lat, lng,
                    doctor.getFacility().getLatitude(),
                    doctor.getFacility().getLongitude()
            );
            travelMinutes = DistanceUtil.estimatedTravelMinutes(distanceKm);
        }

        List<Slot> availableSlots = getAvailableSlots(doctor.getId(), date);

        List<LocalTime> nextAvailableTimes = availableSlots.stream()
                .map(Slot::getStartTime)
                .sorted()
                .limit(5)
                .toList();

        return DoctorSearchResult.builder()
                .doctorId(doctor.getId())
                .doctorName(formatDoctorName(doctor.getName()))
                .specialization(doctor.getSpecialization())
                .rating(doctor.getRating())
                .verified(doctor.isVerified())
                .facilityName(doctor.getFacility().getName())
                .facilityAddress(doctor.getFacility().getAddress())
                .distanceKm(distanceKm)
                .estimatedTravelMinutes(travelMinutes)
                .consultationFee(doctor.getConsultationFee())
                .availableSlotCount(availableSlots.size())
                .nextAvailableSlots(nextAvailableTimes)
                .build();
    }

    private List<Slot> getAvailableSlots(Long doctorId, LocalDate date) {
        return slotRepository.findByProviderTypeAndProviderIdAndDateAndStatus(
                ProviderType.DOCTOR,
                doctorId,
                date,
                SlotStatus.AVAILABLE
        );
    }

    private Comparator<DoctorSearchResult> byNearestDistance() {
        return Comparator.comparing(
                DoctorSearchResult::getDistanceKm,
                Comparator.nullsLast(Double::compareTo)
        );
    }

    private String formatDoctorName(String name) {
        if (name == null || name.isBlank()) {
            return "Unknown Doctor";
        }
        String cleanName = name.replaceFirst("(?i)^Dr\\.?\\s*", "").trim();
        return "Dr. " + cleanName;
    }
}