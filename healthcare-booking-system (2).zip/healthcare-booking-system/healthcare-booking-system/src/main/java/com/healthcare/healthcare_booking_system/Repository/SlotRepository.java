package com.healthcare.healthcare_booking_system.Repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.healthcare.healthcare_booking_system.Entitys.ProviderType;
import com.healthcare.healthcare_booking_system.Entitys.Slot;
import com.healthcare.healthcare_booking_system.Entitys.SlotStatus;

@Repository
public interface SlotRepository extends JpaRepository<Slot, Long> {

    List<Slot> findByProviderTypeAndProviderIdAndDateAndStatus(
            ProviderType providerType,
            Long providerId,
            LocalDate date,
            SlotStatus status);

    List<Slot> findByProviderTypeAndProviderIdAndDate(
            ProviderType providerType,
            Long providerId,
            LocalDate date);

    long countByProviderTypeAndProviderIdAndDateAndStatus(
            ProviderType providerType,
            Long providerId,
            LocalDate date,
            SlotStatus status);

    List<Slot> findByProviderTypeAndProviderIdAndDateAndStatusIn(
            ProviderType providerType,
            Long providerId,
            LocalDate date,
            List<SlotStatus> statuses);
}