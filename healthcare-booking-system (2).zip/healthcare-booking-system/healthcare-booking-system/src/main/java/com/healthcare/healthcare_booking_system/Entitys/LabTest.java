package com.healthcare.healthcare_booking_system.Entitys;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "lab_test")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class LabTest {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@Column(nullable = false)
	private String testName;
	
	@Column(nullable = false)
	private Double price;
	
	private Integer reportTimeHours;
	
	private boolean homeSampleCollection;
	
	  @ManyToOne(fetch = FetchType.LAZY)
	  @JoinColumn(name = "facility_id", nullable = false)
      private Facility facility;

	

}
