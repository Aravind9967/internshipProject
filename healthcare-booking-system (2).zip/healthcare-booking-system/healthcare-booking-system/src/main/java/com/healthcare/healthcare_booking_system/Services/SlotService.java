package com.healthcare.healthcare_booking_system.Services;

import org.springframework.stereotype.Service;

import com.healthcare.healthcare_booking_system.DTOs.SlotRequest;
import com.healthcare.healthcare_booking_system.Entitys.ProviderType;
import com.healthcare.healthcare_booking_system.Entitys.Slot;
import com.healthcare.healthcare_booking_system.Entitys.SlotStatus;
import com.healthcare.healthcare_booking_system.Exceptions.InvalidBookingException;
import com.healthcare.healthcare_booking_system.Exceptions.ResourceNotFoundException;
import com.healthcare.healthcare_booking_system.Repository.DoctorRepository;
import com.healthcare.healthcare_booking_system.Repository.LabTestRepository;
import com.healthcare.healthcare_booking_system.Repository.SlotRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class SlotService {

    private final SlotRepository slotRepository;
    private final DoctorRepository doctorRepository;
    private final LabTestRepository labTestRepository;

    // ==================== ADD SLOT ====================
    public Slot addSlot(SlotRequest request) {

        validateProviderExists(request.getProviderType(), request.getProviderId());

        if (!request.getEndTime().isAfter(request.getStartTime())) {
            throw new InvalidBookingException("Slot end time must be after start time.");
        }

        Slot slot = Slot.builder()
                .providerType(request.getProviderType())
                .providerId(request.getProviderId())
                .date(request.getDate())
                .startTime(request.getStartTime())
                .endTime(request.getEndTime())
                .status(SlotStatus.AVAILABLE)
                .build();

        return slotRepository.save(slot);
    }

    // ==================== DELETE SLOT ====================
    public void deleteSlot(Long slotId) {
        Slot slot = slotRepository.findById(slotId)
                .orElseThrow(() -> ResourceNotFoundException.of("Slot", slotId));
        slotRepository.delete(slot);
    }

    // ==================== HELPER ====================
    private void validateProviderExists(ProviderType type, Long providerId) {

        boolean exists;
        String resourceName;

        switch (type) {
            case DOCTOR:
                exists = doctorRepository.existsById(providerId);
                resourceName = "Doctor";
                break;
            case LAB:
                exists = labTestRepository.existsById(providerId);
                resourceName = "LabTest";
                break;
            default:
                throw new InvalidBookingException("Unsupported provider type: " + type);
        }

        if (!exists) {
            throw ResourceNotFoundException.of(resourceName, providerId);
        }
    }
}