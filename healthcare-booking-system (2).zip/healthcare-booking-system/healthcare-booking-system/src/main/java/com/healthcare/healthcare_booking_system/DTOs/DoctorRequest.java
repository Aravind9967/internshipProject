package com.healthcare.healthcare_booking_system.DTOs;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class DoctorRequest {

    @NotBlank
    private String name;

    @NotBlank
    private String specialization;

    private Integer yearsOfExperience;

    @NotNull
    private Double consultationFee;

    private Double rating;

    private boolean verified = false;

    @NotNull
    private Long facilityId;
}