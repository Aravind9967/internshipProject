package com.healthcare.healthcare_booking_system.Repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.healthcare.healthcare_booking_system.Entitys.Appointment;
import com.healthcare.healthcare_booking_system.Entitys.AppointmentStatus;
import com.healthcare.healthcare_booking_system.Entitys.ProviderType;

public interface AppointmentRepository extends JpaRepository<Appointment, Long> {
    
    List<Appointment> findByProviderTypeAndProviderIdAndStatus(
        ProviderType providerType, 
        Long providerId, 
        AppointmentStatus status
    );  
    
    List<Appointment> findByPatientPhone(String patientPhone);

    long countByProviderTypeAndProviderIdAndStatusAndBookedAtBetween(
        ProviderType providerType,
        Long providerId,
        AppointmentStatus status,
        LocalDateTime start,
        LocalDateTime end
    );
}