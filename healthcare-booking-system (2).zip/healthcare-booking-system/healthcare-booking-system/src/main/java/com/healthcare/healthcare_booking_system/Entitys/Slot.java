package com.healthcare.healthcare_booking_system.Entitys;

import java.time.LocalDate;
import java.time.LocalTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Entity
@Table(name = "slot")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Slot {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Enumerated(EnumType.STRING)
	@Column(nullable = false)
	private ProviderType providerType;
	 @Column(nullable = false)
	 private Long providerId;
	 
	  @Column(nullable = false)
	  private LocalDate date;

	  @Column(nullable = false)
	  private LocalTime startTime;

      @Column(nullable = false)
      private LocalTime endTime;
	
	  @Enumerated(EnumType.STRING)
	  @Column(nullable = false)
	  private SlotStatus status;



}
