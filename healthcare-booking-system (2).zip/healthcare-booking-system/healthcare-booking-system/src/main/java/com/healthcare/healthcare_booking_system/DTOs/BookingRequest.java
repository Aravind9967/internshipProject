package com.healthcare.healthcare_booking_system.DTOs;

import com.healthcare.healthcare_booking_system.Entitys.ProviderType;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@AllArgsConstructor
@Builder
public class BookingRequest {

    @NotBlank
    private String patientName;

    @NotBlank
    private String patientPhone;          // fixed casing (was PatientPhone)

    @NotNull
    private ProviderType providerType;    // fixed: was @NotBlank

    @NotNull
    private Long providerId;

    @NotNull
    private Long slotId;                  // fixed: was @NotBlank
}