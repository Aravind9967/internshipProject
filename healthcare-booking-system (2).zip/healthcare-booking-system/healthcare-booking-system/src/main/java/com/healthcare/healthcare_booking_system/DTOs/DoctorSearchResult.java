package com.healthcare.healthcare_booking_system.DTOs;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.time.LocalTime;
import java.util.List;

@Data
@AllArgsConstructor
@Builder
public class DoctorSearchResult {
	 private Long doctorId;
	    private String doctorName;
	    private String specialization;
	    private Double rating;
	    private boolean verified;
	    private String facilityName;
	    private String facilityAddress;
	    private Double distanceKm;
	    private Integer estimatedTravelMinutes;
	    private Double consultationFee;
	    private int availableSlotCount;
	    private List<LocalTime> nextAvailableSlots; 

}
