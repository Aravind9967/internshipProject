package com.healthcare.healthcare_booking_system.Entitys;

public enum ProviderType {
	DOCTOR,
	CLINIC,
	LAB

}
